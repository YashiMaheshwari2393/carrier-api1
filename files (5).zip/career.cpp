#include "httplib.h"
#include "json.hpp"
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;
using json = nlohmann::json;

class AstroVision
{
private:
    string name;
    string dob;
    string place;

public:

    // Constructor
    AstroVision(string n, string d, string p)
    {
        name = n;
        dob = d;
        place = p;
    }

    // Function to generate zodiac sign
    string getZodiac()
    {
        int day, month, year;
        sscanf(dob.c_str(), "%d-%d-%d", &day, &month, &year);

        if((month==3 && day>=21) || (month==4 && day<=19))   return "Aries";
        else if((month==4 && day>=20) || (month==5 && day<=20))  return "Taurus";
        else if((month==5 && day>=21) || (month==6 && day<=20))  return "Gemini";
        else if((month==6 && day>=21) || (month==7 && day<=22))  return "Cancer";
        else if((month==7 && day>=23) || (month==8 && day<=22))  return "Leo";
        else if((month==8 && day>=23) || (month==9 && day<=22))  return "Virgo";
        else if((month==9 && day>=23) || (month==10 && day<=22)) return "Libra";
        else if((month==10 && day>=23) || (month==11 && day<=21)) return "Scorpio";
        else if((month==11 && day>=22) || (month==12 && day<=21)) return "Sagittarius";
        else if((month==12 && day>=22) || (month==1 && day<=19)) return "Capricorn";
        else if((month==1 && day>=20) || (month==2 && day<=18))  return "Aquarius";
        else return "Pisces";
    }

    // Validate date
    bool isValid()
    {
        int day, month, year;
        sscanf(dob.c_str(), "%d-%d-%d", &day, &month, &year);
        return day >= 1 && day <= 31 &&
               month >= 1 && month <= 12 &&
               year >= 1900 && year <= 2100;
    }

    // Career generator - returns JSON string
    string generateCareer()
    {
        vector<string> careers = {
            "Software Engineer", "Doctor", "Data Scientist", "Entrepreneur",
            "Teacher", "Astrologer", "Digital Marketer", "Civil Engineer",
            "Graphic Designer", "Psychologist", "Content Creator",
            "Research Scientist", "Business Analyst", "Lawyer"
        };

        srand((unsigned)time(0));
        vector<string> chosen;
        vector<int> used;
        while ((int)chosen.size() < 4) {
            int idx = rand() % careers.size();
            bool duplicate = false;
            for (int u : used) if (u == idx) { duplicate = true; break; }
            if (!duplicate) {
                chosen.push_back(careers[idx]);
                used.push_back(idx);
            }
        }

        json res;
        res["name"]           = name;
        res["dob"]            = dob;
        res["place_of_birth"] = place;
        res["zodiac_sign"]    = getZodiac();
        res["career_suggestions"] = chosen;
        res["astro_message"]  = "Your stars indicate strong potential, " + name +
                                "! Choose a career that matches your passion and dedication.";

        return res.dump();
    }
};

// ─── Main ────────────────────────────────────────────────────────────────────
int main()
{
    httplib::Server svr;

    // Health check
    svr.Get("/", [](const httplib::Request&, httplib::Response& res) {
        res.set_content("AstroVision Career API is running! POST to /career", "text/plain");
    });

    // GET /career - usage hint
    svr.Get("/career", [](const httplib::Request&, httplib::Response& res) {
        json hint;
        hint["usage"]   = "Send a POST request to /career";
        hint["example"] = {{"name","Yashi"},{"dob","23-03-2000"},{"place","Rajasthan"}};
        res.set_content(hint.dump(), "application/json");
    });

    // POST /career
    svr.Post("/career", [](const httplib::Request& req, httplib::Response& res) {
        json body;
        try {
            body = json::parse(req.body);
        } catch (...) {
            json err;
            err["error"] = "Invalid JSON body";
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        if (!body.contains("name") || !body.contains("dob") || !body.contains("place")) {
            json err;
            err["error"] = "Missing fields. Required: name, dob (DD-MM-YYYY), place";
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        AstroVision user(body["name"], body["dob"], body["place"]);

        if (!user.isValid()) {
            json err;
            err["error"] = "Invalid date. Use format DD-MM-YYYY";
            res.status = 400;
            res.set_content(err.dump(), "application/json");
            return;
        }

        res.set_content(user.generateCareer(), "application/json");
    });

    const char* port_env = getenv("PORT");
    int port = port_env ? atoi(port_env) : 8080;

    printf("AstroVision API running on port %d\n", port);
    svr.listen("0.0.0.0", port);
    return 0;
}
